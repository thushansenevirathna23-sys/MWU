OrbiteCine44 - Movie Discovery Website

FILES
- index.html : page structure
- style.css  : visual design and responsive styles
- script.js  : sample movie data and interactive features

RUN LOCALLY
1. Extract the OrbiteCine44.zip archive.
2. Keep index.html, style.css, and script.js in the same folder.
3. Open index.html in a modern browser.

NOTES
- Internet is needed for remote fonts and poster/backdrop images.
- This demo uses sample movie metadata; it is not connected to a live movie API.
- Movie links open official trailer links and a search for legitimate viewing options; regional availability is not verified.
- Watchlist uses browser localStorage.
- Do not host or link to unauthorized copyrighted movie copies.
